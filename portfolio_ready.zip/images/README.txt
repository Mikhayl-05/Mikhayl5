Masukkan foto profil dan foto karya ke folder ini.
Nama file harus:
- profil.jpg
- karya1.jpg
- karya2.jpg
- karya3.jpg
